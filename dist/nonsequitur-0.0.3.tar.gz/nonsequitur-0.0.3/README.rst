nonsequitur.py
=======================

A Python module for generating non sequitur text.

----

This is the README file for the project.
