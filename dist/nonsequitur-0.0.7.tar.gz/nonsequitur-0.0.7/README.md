# nonsequitur.py

A Python module for generating non sequitur text.

## Installation

pip install --no-cache-dir nonsequitur

## Available functions

* america_russia()
* bar()
* chicken()
* cows()
* knock_knock()
* lightbulb()
* violas()
