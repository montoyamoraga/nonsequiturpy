import os
from os import system
import time
import string
import random
import urllib


def joke():
    print "this is a premise"
    print "this is a punchline"
